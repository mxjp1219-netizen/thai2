# Thai A2.1–A2.7 Interactive Learning App — TTS 修正版

## 本次修正：小喇叭沒有聲音

- 朗讀會先檢查裝置是否有泰語 `th-TH` 系統語音。
- 若沒有泰語系統語音，改用線上泰語音訊播放，不需要另行安裝語音套件；需保持網路連線。
- 若瀏覽器內建語音發生錯誤或沒有開始播放，會嘗試切換到線上語音。
- 網頁會顯示「正在播放／朗讀完成／播放失敗」狀態，不再靜默吞掉錯誤。
- 朗讀按鈕仍保留在單字、句子、對話及學習卡片中。

## 部署

### Netlify
解壓縮 ZIP，把包含 `index.html` 的資料夾直接拖進 Netlify 部署區即可。

### GitHub Pages
建立 repository → 上傳本資料夾 → Settings → Pages → Deploy from branch → 選 main / root。

## 檔案

若只需要網站，至少要保留 `index.html`。若要使用網站上的 PDF / Word 按鈕，請把同一資料夾內的 PDF / DOCX 一起上傳。

## 注意

線上語音備援需要網路。線上 TTS 服務的網址由第三方維護，未來可能變更；如線上語音故障，網頁會顯示錯誤提示。
